# QuantaEdge Class 6 Hindi — Premium learning content

## Contents
- One unified complete-book PDF for Maths and one for Science, authored as coherent documents rather than merged chapter PDFs.
- 22 standalone chapter-wise concept PDFs: concepts, worked examples, recap and QuantaEdge Advanced only; no practice questions, tests or answers.
- 22 editable QuantaEdge authoring JSON bundles and matching question banks, editable DOCX files, illustrations and a topic-coverage matrix.
- The existing question count remains 13 per chapter (286 total).

## Local database import (PowerShell)
Copy this ZIP into the repository root next to `docker-compose.yml`, then run from the local QuantaEdge checkout. The importer writes DRAFT records only and never publishes content.

```powershell
cd D:\QuantaEdge\QuantaEdge
git pull origin main
.\scripts\quantaedge-local.ps1 rebuild

# Sign in to local Admin, then read QE_SESSION from your browser's localhost cookies.
# Keep it private: do not send it in chat or commit it.
$env:QUANTAEDGE_API_BASE_URL = "http://localhost:8080"
$env:QUANTAEDGE_ADMIN_SESSION = "<QE_SESSION cookie value>"

# First run no-write validation and inspect the JSON report for failures.
python .\scripts\import_ncert_class6_drafts.py --package ".\QuantaEdge_Class6_QuantaEdge_Premium_Hindi_Package.zip"

# Only after the dry-run passes, insert draft records into the local database.
python .\scripts\import_ncert_class6_drafts.py --package ".\QuantaEdge_Class6_QuantaEdge_Premium_Hindi_Package.zip" --apply
```

Flyway migration `V48__ncert_class6_quantaedge_learning_path.sql` creates the Class 6 Maths/Science chapter inventory and archives legacy learning rows without deleting them. The importer creates lessons and questions as DRAFT. Verify the import report and Admin Content Studio before separate editorial review and publication.

## Coverage gate
`coverage/CLASS6_TOPIC_COVERAGE_MATRIX.csv` enumerates each authored topic, worked example, misconception guard, Advanced layer and website lesson mapping. `coverage/CLASS6_SOURCE_COVERAGE_CHECKLIST.csv` explicitly tracks definitions, examples, activities, figures/tables and end-of-chapter outcomes. The precise selected edition's source pages still require line-by-line review; do not mark the books ready to publish until each applicable item is checked.
